# -*- coding: utf-8 -*-
from flask import Flask, render_template, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms import EmailField, IntegerField, SearchField
from wtforms.validators import DataRequired
from data import db_session
from data.users import User
from data.movies import Movie
from data.actors import Actor
from data.directors import Director
from data.reviews import Review
from flask_login import login_required, login_user, LoginManager, logout_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask import make_response, jsonify, request
from flask_restful import reqparse, abort, Api, Resource
import data.movies_resource as movies_resource
import data.actors_resource as actors_resource
import data.directors_resource as directors_resource
import flask_login


ADMIN_EMAIL = "admin@admin.com"
ADMIN_PASSWORD = "adminpassword228"

class MovieForm(FlaskForm):
    name = StringField('Название', validators=[DataRequired()])
    director = IntegerField('id режиссёра', validators=[DataRequired()])
    actors = StringField("id актёров")
    duration = IntegerField('Продолжительность', validators=[DataRequired()])
    year = IntegerField('Год выхода', validators=[DataRequired()])
    genres = StringField('Жанры')
    submit = SubmitField('Добавить')

class ActorForm(FlaskForm):
    name = StringField('Имя', validators=[DataRequired()])
    year = IntegerField('Год рождения', validators=[DataRequired()])
    submit = SubmitField('Добавить')

class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')
    

class RegisterForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    password_again = PasswordField('Подтвердите пароль', validators=[DataRequired()])
    nickname = StringField('Имя пользователя', validators=[DataRequired()])
    submit = SubmitField('Зарегистрироваться')

class ReviewForm(FlaskForm):
    submit = SubmitField('Оставить отзыв')

class SearchForm(FlaskForm):
    search = SearchField('Поиск')
    submit = SubmitField('Искать')

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)
api = Api(app)
api.add_resource(movies_resource.MoviesListResource, '/api/movies')
api.add_resource(movies_resource.MoviesResource, '/api/movies/<movie_name>')
api.add_resource(actors_resource.ActorsListResource, '/api/actors')
api.add_resource(actors_resource.ActorsResource, '/api/actors/<actor_name>')
api.add_resource(directors_resource.DirectorsListResource, '/api/directors')
api.add_resource(directors_resource.DirectorsResource, '/api/directors/<director_name>')

@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)

@login_manager.user_loader
def load_user(user_id):
    session = db_session.create_session()
    return session.query(User).get(user_id)

@app.route('/')
def a():
    return redirect('/movies')

@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        session = db_session.create_session()
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="email is already taken")
        if session.query(User).filter(User.nickname == form.nickname.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="nickname is already taken")
        user = User(
            nickname=form.nickname.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        user = session.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")

@app.route('/movies', methods=['GET', 'POST'])
def movies():
    form = SearchForm()
    req = ''
    srt = 'name'
    if form.validate_on_submit():
        req = form.search.data
        srt = request.form['sort']
    session = db_session.create_session()
    movies = session.query(Movie).filter(Movie.name.like('%' + req + '%'))
    reverse = False
    if srt == 'name':
        key = lambda x: x.name
    elif srt == 'k':
        key = lambda x: x.k
        reverse = True
    elif srt == 'year1':
        key = lambda x: x.year
    elif srt == 'year2':
        key = lambda x: x.year
        reverse = True
    elif srt == 'dur1':
        key = lambda x: x.duration
    elif srt == 'dur2':
        key = lambda x: x.duration
        reverse = True
    movies = sorted(movies, key=key, reverse=reverse)
    if len(movies) > 30:
        movies = movies[:30]
    actors = dict()
    directors = dict()
    for m in movies:
        actors[m.id] = get_actors(m)
        directors[m.id] = get_director(m)
    return render_template('movies.html', title='Фильмы', form=form,
                           movies=movies, directors=directors, actors=actors)

@app.route('/movies/<int:movie_id>', methods=['GET', 'POST'])
def one_movie(movie_id):
    form = ReviewForm()
    session = db_session.create_session()
    if form.validate_on_submit():
        r = Review()
        r.text = request.form['text']
        r.movie = movie_id
        r.user = flask_login.current_user.nickname
        session.add(r)
        movie = session.query(Movie).get(movie_id)
        movie.k += 1
        session.commit()
    movie = session.query(Movie).get(movie_id)
    reviews = session.query(Review).filter(Review.movie == movie_id)
    text = dict()
    for r in reviews:
        text[r.id] = r.text.split('\n')
    session.commit()
    no_reviews = False
    if len(list(reviews)) == 0:
        no_reviews = True
    return render_template('movie.html', title=movie.name, m=movie,
                           actors=get_actors(movie), director=get_director(movie),
                           reviews=reviews, form=form, no_reviews=no_reviews,
                           text=text)

@app.route('/directors', methods=['GET', 'POST'])
def directors():
    form = SearchForm()
    req = ''
    srt = 'name'
    if form.validate_on_submit():
        req = form.search.data
        srt = request.form['sort']
    session = db_session.create_session()
    directors = session.query(Director).filter(Director.name.like('%' + req + '%'))
    reverse = False
    if srt == 'name':
        key = lambda x: x.name
    elif srt == 'year1':
        key = lambda x: x.year
    elif srt == 'year2':
        key = lambda x: x.year
        reverse = True
    directors = sorted(directors, key=key, reverse=reverse)
    if len(directors) > 30:
        directors = directors[:30]
    k = dict()
    for d in directors:
        movies = session.query(Movie).filter(Movie.director == d.id).all()
        k[d.id] = len(movies)
    return render_template('directors.html', title='Режиссёры', form=form,
                           directors=directors, k=k)

@app.route('/directors/<int:director_id>', methods=['GET'])
def one_director(director_id):
    session = db_session.create_session()
    director = session.query(Director).get(director_id)
    movies = session.query(Movie).filter(Movie.director == director_id).all()
    actors = dict()
    for m in movies:
        actors[m.id] = get_actors(m)    
    return render_template('director.html', title=director.name, movies=movies,
                           director=director, actors=actors, k=len(movies))

@app.route('/actors', methods=['GET', 'POST'])
def actors():
    form = SearchForm()
    req = ''
    srt = 'name'
    if form.validate_on_submit():
        req = form.search.data
        srt = request.form['sort']
    session = db_session.create_session()
    actors = session.query(Actor).filter(Actor.name.like('%' + req + '%'))
    reverse = False
    if srt == 'name':
        key = lambda x: x.name
    elif srt == 'year1':
        key = lambda x: x.year
    elif srt == 'year2':
        key = lambda x: x.year
        reverse = True
    actors = sorted(actors, key=key, reverse=reverse)
    if len(actors) > 30:
        actors = actors[:30]
    k = dict()
    for a in actors:
        movies = session.query(Movie).filter(Movie.actors.like('%' + str(a.id) + '%')).all()
        for m in movies:
            if a.id not in m.actors.split(', '):
                movies.remove(m)
        k[a.id] = len(movies)
    return render_template('actors.html', title='Актёры', form=form,
                           actors=actors, k=k)

@app.route('/actors/<int:actor_id>', methods=['GET'])
def one_actor(actor_id):
    session = db_session.create_session()
    actor = session.query(Actor).get(actor_id)
    movies = session.query(Movie).filter(Movie.actors.like('%' + str(actor_id) + '%')).all()
    for m in movies:
        if actor_id not in m.actors.split(', '):
            movies.remove(m)
    actors = dict()
    directors = dict()
    for m in movies:
        actors[m.id] = get_actors(m)
        directors[m.id] = get_director(m)   
    return render_template('actor.html', title=actor.name, movies=movies, actor=actor,
                           directors=directors, actors=actors, k=len(movies))

@app.route('/add_actor', methods=['GET', 'POST'])
def add_actor():
    form = ActorForm()
    session = db_session.create_session()
    if form.validate_on_submit():
        actor = Actor()
        actor.name = form.name.data
        actor.year = form.year.data
        session.add(actor)
        session.commit()
        return redirect('/actors')
    return render_template('add_actor.html', title='Добавление Актёра', form=form)

@app.route('/add_director', methods=['GET', 'POST'])
def add_director():
    form = ActorForm()
    session = db_session.create_session()
    if form.validate_on_submit():
        director = Director()
        director.name = form.name.data
        director.year = form.year.data
        session.add(director)
        session.commit()
        return redirect('/directors')
    return render_template('add_actor.html', title='Добавление Режиссёра', form=form)

@app.route('/add_movie', methods=['GET', 'POST'])
def add_movie():
    form = MovieForm()
    session = db_session.create_session()
    if form.validate_on_submit():
        movie = Movie()
        movie.name = form.name.data
        movie.year = form.year.data
        movie.duration = form.duration.data
        movie.director = form.director.data
        movie.actors = form.actors.data
        movie.genres = form.genres.data
        movie.k = 0
        session.add(movie)
        session.commit()
        return redirect('/movies')
    return render_template('add_movie.html', title='Добавление Фильма', form=form)

def get_actors(m):
    actors = list()
    session = db_session.create_session()
    for actor_id in m.actors.split(', '):
        actor = session.query(Actor).get(int(actor_id))
        actors.append((actor.id, actor.name))
    return actors

def get_director(m):
    session = db_session.create_session()
    director = session.query(Director).get(m.director)
    return (director.id, director.name)


def main():
    db_session.global_init("db/db.sqlite")
    session = db_session.create_session()
    if not session.query(User).first():
        admin = User()
        admin.nickname = "admin"
        admin.email = ADMIN_EMAIL
        admin.set_password(ADMIN_PASSWORD)
        session.add(admin)
    session.commit()
    app.run(port=8080, host='127.0.0.1')


if __name__ == '__main__':
    main()