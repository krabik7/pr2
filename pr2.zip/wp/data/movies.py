import sqlalchemy
from .db_session import SqlAlchemyBase
from sqlalchemy_serializer import SerializerMixin


class Movie(SqlAlchemyBase, SerializerMixin):
    __tablename__ = 'movies'
    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    duration = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    year = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    director = sqlalchemy.Column(sqlalchemy.Integer,
                                 sqlalchemy.ForeignKey("directors.id"),
                                 nullable=True)
    actors = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    genres = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    k = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
