from flask_restful import abort, Resource
from .directors import Director
from flask import jsonify
from . import db_session

def abort_if_director_not_found(director_name):
    session = db_session.create_session()
    director = session.query(Director).filter(Director.name == director_name).first()
    if not director:
        abort(404, message=f"Director {director_name} not found")


class DirectorsResource(Resource):
    def get(self, director_name):
        abort_if_director_not_found(director_name)
        session = db_session.create_session()
        director = session.query(Director).filter(Director.name == director_name).first()
        return jsonify({'director': director.to_dict(
            only=('id', 'name', 'year'))})


class DirectorsListResource(Resource):
    def get(self):
        session = db_session.create_session()
        directors = session.query(Director).all()
        return jsonify({'directors': [item.to_dict(
            only=('id', 'name', 'year')) for item in directors]})
