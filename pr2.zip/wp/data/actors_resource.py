from flask_restful import abort, Resource
from .actors import Actor
from flask import jsonify
from . import db_session

def abort_if_actor_not_found(actor_name):
    session = db_session.create_session()
    actor = session.query(Actor).filter(Actor.name == actor_name).first()
    if not actor:
        abort(404, message=f"Actor {actor_name} not found")


class ActorsResource(Resource):
    def get(self, actor_name):
        abort_if_actor_not_found(actor_name)
        session = db_session.create_session()
        actor = session.query(Actor).filter(Actor.name == actor_name).first()
        return jsonify({'actor': actor.to_dict(
            only=('id', 'name', 'year'))})


class ActorsListResource(Resource):
    def get(self):
        session = db_session.create_session()
        actors = session.query(Actor).all()
        return jsonify({'actors': [item.to_dict(
            only=('id', 'name', 'year')) for item in actors]})
