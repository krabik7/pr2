from flask_restful import abort, Resource
from .movies import Movie
from flask import jsonify
from . import db_session

def abort_if_movie_not_found(movie_name):
    session = db_session.create_session()
    movie = session.query(Movie).filter(Movie.name == movie_name).first()
    if not movie:
        abort(404, message=f"Movie {movie_name} not found")


class MoviesResource(Resource):
    def get(self, movie_name):
        abort_if_movie_not_found(movie_name)
        session = db_session.create_session()
        movie = session.query(Movie).filter(Movie.name == movie_name).first()
        return jsonify({'movie': movie.to_dict(
            only=('id', 'name', 'year', 'director', 'actors',
                  'duration', 'genres'))})


class MoviesListResource(Resource):
    def get(self):
        session = db_session.create_session()
        movies = session.query(Movie).all()
        return jsonify({'movies': [item.to_dict(
            only=('id', 'name', 'year', 'director', 'actors',
                  'duration', 'genres')) for item in movies]})
