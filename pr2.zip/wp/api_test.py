from requests import get

print(get('http://localhost:8080/api/movies').json())
print(get('http://localhost:8080/api/movies/Movie1').json())
print(get('http://localhost:8080/api/actors').json())
print(get('http://localhost:8080/api/actors/Actor2').json())
print(get('http://localhost:8080/api/directors').json())
print(get('http://localhost:8080/api/directors/Director1').json())

print(get('http://localhost:8080/api/movies/sdkflsdps').json())
print(get('http://localhost:8080/api/actors/sskdfjslk').json())